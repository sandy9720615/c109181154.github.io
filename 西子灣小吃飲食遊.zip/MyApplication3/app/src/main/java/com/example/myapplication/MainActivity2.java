package com.example.myapplication;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import java.util.HashSet;
import java.util.Set;

public class MainActivity2 extends AppCompatActivity {
    private Spinner sp1, sp2, sp3;
    private String[] drink;
    private TextView outputTextView;
    private RatingBar ratingBar;

    private static final String ORDER_HISTORY_PREF = "OrderHistoryPref";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Button btnBackToMain = findViewById(R.id.backbtn4);
        btnBackToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToMainActivity();
            }
        });


        // 使用 AppCompatDelegate 設置應用主題（例如，深色主題）
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

        sp1 = findViewById(R.id.spinner);
        ArrayAdapter<String> a1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, getCourses());
        sp1.setAdapter(a1);

        drink = getResources().getStringArray(R.array.drink);
        sp2 = findViewById(R.id.spinner2);
        ArrayAdapter<String> a2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, drink);
        sp2.setAdapter(a2);

        String[] add = {"薯條 - $30", "雞米花 - $40", "雞塊 - $35", "蘋果派 - $45", "雞腿排 - $50"};
        sp3 = findViewById(R.id.spinner3);
        ArrayAdapter<String> a3 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, add);
        sp3.setAdapter(a3);



        // 評價功能


        Button btnOrder = findViewById(R.id.btnOrder);
        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 新增彈出對話框詢問是否是學生
                showStudentDialog();
            }
        });
    }

    private void showStudentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("學生優惠");
        builder.setMessage("您是否是學生？");
        builder.setPositiveButton("是", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // 如果是學生，執行訂購相關的邏輯
                handleOrder(true);
            }
        });
        builder.setNegativeButton("否", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // 如果不是學生，執行訂購相關的邏輯
                handleOrder(false);
            }
        });
        builder.show();
    }
    private void goToMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void handleOrder(boolean isStudent) {
        // 訂單的處理邏輯
        // 在這裡執行訂購相關的邏輯
        String mainCourse = sp1.getSelectedItem().toString();
        String drinkChoice = sp2.getSelectedItem().toString();
        String addChoice = sp3.getSelectedItem().toString();

        // 新增價格相關的處理
        double mainCoursePrice = extractPrice(mainCourse);
        double drinkPrice = extractPrice(drinkChoice);
        double addChoicePrice = extractPrice(addChoice);
        double totalPrice = mainCoursePrice + drinkPrice + addChoicePrice;

        // 如果是學生，總價格打9折
        if (isStudent) {
            totalPrice *= 0.9;
        }

        // 保存訂單至歷史紀錄
        saveOrderToHistory(mainCourse, drinkChoice, addChoice, totalPrice);
        // 顯示訂單確認對話框後，詢問評價
        showOrderConfirmationDialog(mainCourse, drinkChoice, addChoice, totalPrice);
    }

    private void showOrderConfirmationDialog(String mainCourse, String drinkChoice, String addChoice, double totalPrice) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("訂購成功");
        builder.setMessage("感謝您的訂購！您選擇的菜品是：" +
                mainCourse + "，飲料是：" + drinkChoice + "，附餐是：" + addChoice +
                "\n總價格：" + totalPrice + "元");
        builder.setPositiveButton("確定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // 詢問評價
                askForRating();
            }
        });
        builder.show();
    }

    private void askForRating() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("評價");
        builder.setMessage("請給此訂單評分：");

        // 載入包含RatingBar的佈局
        View ratingLayout = getLayoutInflater().inflate(R.layout.aaa, null);
        final RatingBar ratingBar = ratingLayout.findViewById(R.id.dialogRatingBar);
        builder.setView(ratingLayout);

        builder.setPositiveButton("確定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                float rating = ratingBar.getRating();
                showRatingConfirmationDialog(rating);
            }
        });

        builder.setNegativeButton("取消", null);
        builder.show();
    }

    private void showRatingConfirmationDialog(float rating) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("評價成功");
        builder.setMessage("感謝您的評價！\n評價：" + rating + "星");
        builder.setPositiveButton("確定", null);
        builder.show();
    }

    private void saveOrderToHistory(String mainCourse, String drinkChoice, String addChoice, double totalPrice) {
        // 讀取現有的訂單歷史
        Set<String> orderHistory = getSharedPreferences(ORDER_HISTORY_PREF, Context.MODE_PRIVATE)
                .getStringSet("orders", new HashSet<String>());

        // 將新訂單添加到歷史中
        String orderDetails = mainCourse + "," + drinkChoice + "," + addChoice + "," + totalPrice;
        orderHistory.add(orderDetails);

        // 將更新後的訂單歷史儲存回 SharedPreferences
        SharedPreferences.Editor editor = getSharedPreferences(ORDER_HISTORY_PREF, Context.MODE_PRIVATE).edit();
        editor.putStringSet("orders", orderHistory);
        editor.apply();
    }

    private double extractPrice(String selectedItem) {
        // 提取價格，假設價格位於字串的最後一個空格後
        String[] parts = selectedItem.split(" ");
        if (parts.length > 1) {
            String priceString = parts[parts.length - 1];
            // 去掉價格中的符號（例如，"$"）並轉換為數字
            return Double.parseDouble(priceString.replace("$", ""));
        }
        return 0.0; // 如果無法提取價格，則返回0
    }

    private void updateTextViewWithAnimation(String mainCourse, String drinkChoice, String addChoice) {
        // 使用淡入效果
        ObjectAnimator alphaAnimator = ObjectAnimator.ofFloat(outputTextView, "alpha", 0f, 1f);
        alphaAnimator.setDuration(1000); // 動畫持續時間 1000 毫秒（1秒）
        alphaAnimator.setInterpolator(new AccelerateDecelerateInterpolator()); // 加速度減速度插值器
        alphaAnimator.start();

        // 更新 TextView
        outputTextView.setText("主菜:" + mainCourse + "\n附餐飲料:" + drinkChoice + "\n附餐:" + addChoice);
    }

    private String[] getCourses() {
        // 在這裡替換成你自己的菜單
        return new String[]{"排骨便當 - $80", "雞腿便當 - $90", "雞排便當 - $85", "蜜汁雞腿便當 - $100", "燒肉飯便當 - $95"};
    }
}
