package com.example.myapplication;
import android.content.BroadcastReceiver;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.app.NotificationManager;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Random;

public class MainActivity3 extends AppCompatActivity {

    private static final int REQUEST_CODE = 123;
    private String[] lunchOptions = {
            "炒飯+蒸蛋 100$",
            "鍋燒麵 90$",
            "不吃 0$",
            "麥當勞 65~200$",
            "丹丹漢堡 100$",
            "炒麵+蝦仁 90$"
    };

    private Button buttonPickLunch;
    private TextView textViewLunchResult;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Button btnBackToMain = findViewById(R.id.btnback16);
        btnBackToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToMainActivity();
            }
        });

        buttonPickLunch = findViewById(R.id.buttonPickLunch);
        textViewLunchResult = findViewById(R.id.textViewLunchResult);

        setupReminder();
        buttonPickLunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickRandomLunch();
            }
        });

        // 檢查通知權限並引導用戶至設定頁面
        checkNotificationPermission();
    }
    private void goToMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }


    private void pickRandomLunch() {
        Random random = new Random();
        int randomIndex = random.nextInt(lunchOptions.length);
        String selectedLunch = lunchOptions[randomIndex];
        textViewLunchResult.setText("今天的午餐是：" + selectedLunch);
    }

    private void setupReminder() {
        // 設定提醒的時間（這裡設定為每天中午12點）
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 12);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);

        // 創建一個Intent，用於觸發BroadcastReceiver
        Intent intent = new Intent(this, ReminderBroadcastReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, REQUEST_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // 取得AlarmManager
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        // 設定重複提醒，這裡設定為每天
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
    }

    private void checkNotificationPermission() {
        // 檢查通知權限，如果未啟用，引導用戶至通知設定頁面
        if (!isNotificationEnabled()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                openNotificationSettings();
            }
        }
    }

    private boolean isNotificationEnabled() {
        // 檢查通知權限是否已啟用
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            return manager.areNotificationsEnabled();
        } else {
            // For older Android versions, it is not straightforward to check notification status
            return true;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void openNotificationSettings() {
        Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
        intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        startActivity(intent);
    }
}