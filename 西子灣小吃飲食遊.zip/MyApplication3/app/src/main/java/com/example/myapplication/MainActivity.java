package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseApp.initializeApp(this);

        firebaseAuth = FirebaseAuth.getInstance();

        // 取得按鈕實例
        ImageButton btnGoToSecondActivity = findViewById(R.id.imageButton);
        ImageButton btnGoToThirdActivity = findViewById(R.id.imageButton2);
        ImageButton btnGoToAc1 = findViewById(R.id.imageButton3);
        ImageButton btnGoToasd4 = findViewById(R.id.imageButton4);
        ImageButton btnGoToasd5 = findViewById(R.id.imageButton5);
        ImageButton btnGoToasd6 = findViewById(R.id.imageButton6);
        ImageButton btnGoToasd7 = findViewById(R.id.imageButton7);
        ImageButton btnGoToasd8 = findViewById(R.id.imageButton8);
        ImageButton btnGoToasd9 = findViewById(R.id.imageButton9);
        ImageButton btnGoToasd10 = findViewById(R.id.imageButton10);

        Button btnGoToLoginActivity = findViewById(R.id.buttonLogin1);
        Button btngoMainActivity2 = findViewById(R.id.button12);
        Button btngoMainActivity3 = findViewById(R.id.button13);


        // 設定按鈕的點擊事件
        btnGoToSecondActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊事件中執行轉跳至 SecondActivity 的操作
                goToSecondActivity();
            }
        });

        // 設定 ImageButton 的點擊事件
        btnGoToThirdActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊事件中執行轉跳至 ThirdActivity 的操作
                goToThirdActivity();
            }
        });
        btnGoToAc1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊事件中執行轉跳至 Ac1 的操作
                goToAc1();
            }
        });
        btnGoToasd4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊事件中執行轉跳至 Ac1 的操作
                goToasd4();
            }

        });
        btnGoToasd5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊事件中執行轉跳至 Ac1 的操作
                goToasd5();
            }

        });
        btnGoToasd6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊事件中執行轉跳至 Ac1 的操作
                goToasd6();
            }

        });
        btnGoToasd7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊事件中執行轉跳至 Ac1 的操作
                goToasd7();
            }

        });
        btnGoToasd8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊事件中執行轉跳至 Ac1 的操作
                goToasd8();
            }

        });
        btnGoToasd9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊事件中執行轉跳至 Ac1 的操作
                goToasd9();
            }

        });
        btnGoToasd10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊事件中執行轉跳至 Ac1 的操作
                goToasd10();
            }

        });

        btnGoToLoginActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊事件中執行轉跳至 LoginActivity 的操作
                goToLoginActivity();
            }
        });
        btngoMainActivity2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 檢查使用者是否已經登入
                if (isUserLoggedIn()) {
                    // 使用者已登入，轉跳至 MainActivity2
                    goMainActivity2();
                } else {
                    // 使用者未登入，提示登入
                    Toast.makeText(MainActivity.this, "請先登入", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btngoMainActivity3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 檢查使用者是否已經登入
                if (isUserLoggedIn()) {
                    // 使用者已登入，轉跳至 MainActivity3
                    goMainActivity3();
                } else {
                    // 使用者未登入，提示登入
                    Toast.makeText(MainActivity.this, "請先登入", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // 轉跳至 SecondActivity 的方法
    private void goToSecondActivity() {
        Intent intent = new Intent(this, SecondActivity.class);
        startActivity(intent);
    }

    // 轉跳至 ThirdActivity 的方法
    private void goToThirdActivity() {
        Intent intent = new Intent(this, ThirdActivity.class);
        startActivity(intent);
    }

    // 轉跳至 Ac1 的方法
    private void goToAc1() {
        Intent intent = new Intent(this, Ac1.class);
        startActivity(intent);
    }
    private void goToasd4() {
        Intent intent = new Intent(this, asd4.class);
        startActivity(intent);
    }
    private void goToasd5() {
        Intent intent = new Intent(this, asd5.class);
        startActivity(intent);
    }
    private void goToasd6() {
        Intent intent = new Intent(this, asd6.class);
        startActivity(intent);
    }
    private void goToasd7() {
        Intent intent = new Intent(this, asd7.class);
        startActivity(intent);
    }
    private void goToasd8() {
        Intent intent = new Intent(this, asd8.class);
        startActivity(intent);
    }
    private void goToasd9() {
        Intent intent = new Intent(this, asd9.class);
        startActivity(intent);
    }
    private void goToasd10() {
        Intent intent = new Intent(this, asd10.class);
        startActivity(intent);
    }

    // 轉跳至 LoginActivity 的方法
    private void goToLoginActivity() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    // 轉跳至 MainActivity2 的方法
    private void goMainActivity2() {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }

    // 轉跳至 MainActivity3 的方法
    private void goMainActivity3() {
        Intent intent = new Intent(this, MainActivity3.class);
        startActivity(intent);
    }

    // 檢查使用者是否已經登入
    private boolean isUserLoggedIn() {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        return user != null;
    }
}
