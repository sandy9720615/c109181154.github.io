package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextEmail, editTextPassword;
    private Button buttonLogin, buttonCreateAccount, buttonLogout;  // 新增登出按鈕

    private FirebaseAuth firebaseAuth;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 初始化 FirebaseAuth
        firebaseAuth = FirebaseAuth.getInstance();

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);
        buttonLogout = findViewById(R.id.buttonLogout);  // 初始化登出按鈕

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 在這裡處理登入邏輯
                signIn();
            }
        });

        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 在這裡處理創建帳號邏輯
                createAccount();
            }
        });

        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 在這裡處理登出邏輯
                signOut();
            }
        });

        Button btnBackToMain = findViewById(R.id.backbtn3);
        btnBackToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToMainActivity();
            }
        });
    }

    private void goToMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void signIn() {
        // 獲取用戶輸入的帳號和密碼
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // 使用 FirebaseAuth 進行帳號密碼登入
        firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // 登入成功
                            Toast.makeText(LoginActivity.this, "登入成功", Toast.LENGTH_SHORT).show();

                            // 在這裡處理登入成功後的操作
                        } else {
                            // 登入失敗
                            Toast.makeText(LoginActivity.this, "登入失敗", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void createAccount() {
        // 獲取用戶輸入的帳號和密碼
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // 使用 FirebaseAuth 創建帳號
        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // 帳號創建成功
                            Toast.makeText(LoginActivity.this, "帳號創建成功", Toast.LENGTH_SHORT).show();
                            // 在這裡處理創建成功後的操作
                        } else {
                            // 帳號創建失敗
                            Toast.makeText(LoginActivity.this, "帳號創建失敗", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void signOut() {
        // 登出
        firebaseAuth.signOut();
        Toast.makeText(LoginActivity.this, "已登出", Toast.LENGTH_SHORT).show();
    }
}
