package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class YourMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 取得按鈕實例
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button btnShowLocation = findViewById(R.id.btnShowLocation);

        // 設定按鈕的點擊事件
        btnShowLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊事件中執行顯示地圖的操作
                showLocationOnMap();
            }
        });
    }

    // 顯示地圖的方法
    private void showLocationOnMap() {
        // 指定目標位置的經緯度
        double latitude = 25.032969;
        double longitude = 121.565418;

        // 建立 URI 字串，包含目標位置的經緯度
        String uri = "geo:" + latitude + "," + longitude + "?q=" + latitude + "," + longitude + "(Label+Name)";

        // 建立 Intent 以啟動 Google Maps App
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        mapIntent.setPackage("com.google.android.apps.maps");

        // 檢查裝置是否安裝了 Google Maps App
        if (mapIntent.resolveActivity(getPackageManager()) != null) {
            // 啟動 Google Maps App
            startActivity(mapIntent);
        }  // 如果沒有安裝 Google Maps App，您可以在這裡處理其他操作
        // 例如顯示訊息提示安裝 Google Maps App
        // 或者導引使用者到 Google Play 安裝 Google Maps

    }
}
