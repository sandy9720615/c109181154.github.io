package com.example.myapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class ReminderBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // 在這裡執行提醒時的操作
        Log.d("Reminder", "Received reminder broadcast.");

        // 你可能想要顯示通知、執行某些操作等等
    }
}
